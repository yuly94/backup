#!/bin/sh
python $APPENGINE/dev_appserver.py --port 8888 build/