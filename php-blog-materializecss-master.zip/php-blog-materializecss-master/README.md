# PHP Blog using Materialize CSS
A simple CRUD Blog App in Core PHP using Materialize CSS

 Below is a list of possible attacks this guide tries to defend against:
SQL Injections
Session Hijacking
Network Eavesdropping
Cross Site Scripting
Brute Force Attacks
Covert Timing Channel Attacks
The approach is to use a mixture of data filtering, encryption and other methods to make the lives of the bad guys just that little bit more difficult.

Please do check the db.php and edit the credentials as per your system :)
