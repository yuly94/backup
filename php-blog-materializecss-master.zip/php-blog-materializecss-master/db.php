<?php
include_once 'psl-config.php'; 
$db = mysqli_connect("localhost","root","redhat123","myblog");
?>