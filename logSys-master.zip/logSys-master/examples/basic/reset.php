<html>
 <head></head>
 <body>
  <?php
  require "config.php";
  \Fr\LS::forgotPassword();
  ?>
 </body>
</html>
