<?php
require_once __DIR__ . "/../src/class.logsys.php";
