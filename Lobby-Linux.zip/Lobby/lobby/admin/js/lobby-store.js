lobby.load(function(){if($("input[name=q]").val()!=="")
$("input[name=q]").focus();});