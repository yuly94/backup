<?php
/**
*
* load.php file for LobbyOS
*
*/
$docRoot = realpath(dirname(__FILE__));
require_once "$docRoot/includes/load.php";
?>
